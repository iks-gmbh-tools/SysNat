#!/bin/sh
"D:/NaspakTests/IntelliJ/jre32/bin/java" -cp "D:/NaspakTests/IntelliJ/plugins/git4idea/lib/git4idea-rt.jar;D:/NaspakTests/IntelliJ/lib/xmlrpc-2.0.1.jar;D:/NaspakTests/IntelliJ/lib/commons-codec-1.10.jar;D:/NaspakTests/IntelliJ/lib/util.jar" org.jetbrains.git4idea.nativessh.GitNativeSshAskPassApp "$@"
